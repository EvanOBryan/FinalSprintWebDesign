fetch('./FinalSprint.json')
    .then(response => response.json())
    .then(data => {
        const container = document.createElement('div');
        container.id = 'peopleContainer';

    data.forEach(person => {
        const personDiv = document.createElement('div');
        personDiv.className = 'person';


        personDiv.innerHTML = `
            <h2>${getFullName(person)}</h2>
            <p>Age: ${getAge(person)}</p>
            <p>Net Income: ${getFavColour(person)}</p>
            <p>Gender: ${chooseGender(person)}</p>
    `;

        container.appendChild(personDiv);
        console.log(getFullName(person));
        console.log(getAge(person));
        console.log(getFavColour(person));
        console.log(chooseGender(person));
    });

    document.body.appendChild(container);
    })
    .catch(error => {
        console.error(error);
    });

    function chooseGender(person) {
        switch(person.Gender){
            case "Female": 
                return`${person.FName} identifies as female.`;
                break;
            case "Male":
                return `${person.FName} identifies as male.`;
                break;
            default:
                return `${person.FName} does not wish to disclose their gender, or does not identify as male or female.`;
        }
    }

    function getFullName(person) {
        return `${person.FName} ${person.LName}`;
    }

    function getAge(person) {    
        return `${person.FName} is ${new Date().getFullYear() - new Date(person.Birthday).getFullYear()} years old.`; 
    }

    function getGender(person){
        return person.Gender;
    }   

    function getFavColour(person){
        return person.FavColour;
    }